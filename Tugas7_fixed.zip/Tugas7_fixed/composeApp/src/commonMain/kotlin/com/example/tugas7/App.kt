package com.example.tugas7

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun App() {
    val settingsVM: SettingsViewModel = viewModel { SettingsViewModel() }
    val theme by settingsVM.theme.collectAsStateWithLifecycle()

    val colorScheme = when (theme) {
        "dark"  -> darkColorScheme()
        "light" -> lightColorScheme()
        else    -> MaterialTheme.colorScheme // system default
    }

    MaterialTheme(colorScheme = colorScheme) {
        MainScreen()
    }
}
